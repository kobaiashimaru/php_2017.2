            <div class="row col-xs-12 col-sm-12 col-md-12 col-lg-12"  align="center">
                <div class="col-sm-6 col-md-4 col-md-offset-2">
                    <div class="thumbnail">
                        <img src="..." alt="...">
                        <div class="caption">
                            <h3>Cadastro</h3>
                            <p><strong>Cadastramento de peças da Automotivo Ltda</strong></p>
                            <p>Antes de efetuar o cadastro de peças, por favor tenha em mãos as informações: código da
                            peça, nome, modelo, ano, fabricante, preço e quantidade.</p>
                            <p><a href="template.php?pagina=formulario" class="btn btn-primary" role="button">Cadastrar</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <img src="..." alt="...">
                        <div class="caption">
                            <h3>Registros</h3>
                            <p><strong>Controle de registro de peças da Automotivo Ltda</strong></p>
                            <p>Nesse menu é possível gerenciar as peças cadastradas podendo listar, buscar, editar e excluir.</p>
                            <p><a href="template.php?pagina=listagem" class="btn btn-primary" role="button">Gerir</a></p>
                        </div>
                    </div>
                </div>
            </div>